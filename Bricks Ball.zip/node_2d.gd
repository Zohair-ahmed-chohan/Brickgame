extends Node2D

var brick_scene = preload("res://briks.tscn")

func _ready():
	$Briks.queue_free()
	for row in 5:
		for col in 10:
			var b = brick_scene.instantiate()
			b.position = Vector2(100 + col * 50, 40 + row * 25)
			add_child(b)
